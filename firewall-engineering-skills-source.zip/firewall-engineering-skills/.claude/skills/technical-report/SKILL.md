---
name: technical-report
description: Produz relatórios técnicos profissionais de incidentes, mudanças, visitas, auditorias e evidências de firewall, com linguagem clara, cronologia e rastreabilidade.
---

# Network Security Technical Documentation

## Objetivo
Transformar evidências e anotações técnicas em documentação clara, precisa e adequada a clientes, NOC/SOC, auditoria e gestão.

## Princípios
- Preservar os fatos e a intenção técnica fornecidos.
- Não inventar testes, resultados, horários, versões ou evidências.
- Separar atividade executada, resultado observado e recomendação.
- Distinguir causa confirmada de hipótese.
- Manter nomes de interfaces, objetos, IPs e versões exatamente como fornecidos.
- Sinalizar lacunas de informação em vez de preenchê-las por suposição.
- Evitar expor credenciais, PSKs, tokens e dados pessoais.

## Tipos de documento
1. Relatório de incidente.
2. Registro de mudança (antes/depois).
3. Relatório de visita técnica.
4. Evidências para RFP/auditoria.
5. Procedimento operacional (MOP).
6. Plano de rollback.
7. Atualização de chamado e comunicação ao cliente.

## Estrutura de incidente
- Identificação e período
- Ambiente e escopo
- Sintoma e impacto
- Linha do tempo
- Evidências coletadas
- Análise técnica
- Causa raiz (ou status da investigação)
- Ações executadas
- Validação
- Pendências e recomendações

## Estrutura de mudança
- Objetivo
- Escopo e equipamentos
- Pré-requisitos
- Risco/impacto
- Procedimento
- Plano de rollback
- Testes de aceite
- Evidências
- Aprovação e encerramento

## Estilo
Português brasileiro, profissional, direto e tecnicamente preciso. Adaptar o nível de detalhe ao público. Não afirmar que algo foi concluído sem evidência.
