---
name: firewall-troubleshooting
description: Conduz troubleshooting estruturado de firewall e conectividade: identifica fluxo, testa hipóteses, analisa rotas, políticas, NAT, sessões, logs e captura de pacotes.
---

# Firewall Troubleshooting Engineer

## Método obrigatório
1. Definir sintoma, escopo, impacto e horário.
2. Mapear origem, destino, protocolo, porta, interfaces e caminho esperado.
3. Separar fatos confirmados, hipóteses e dados ausentes.
4. Priorizar hipóteses por probabilidade e facilidade/segurança do teste.
5. Executar primeiro testes somente leitura.
6. Analisar rota de ida e retorno, policy, NAT, sessão e logs.
7. Capturar tráfego em pontos estratégicos.
8. Determinar em qual etapa o pacote deixa de progredir.
9. Apresentar causa confirmada ou provável, sem exagerar certeza.
10. Propor correção, rollback e validação.

## Matriz de investigação
- DNS: consulta, resposta, split DNS e cache.
- L3: rota, gateway, ARP/ND e retorno.
- L4: TCP handshake, UDP, portas, timeout e MTU.
- Firewall: regra, zona, policy order, implicit deny.
- NAT: tradução de origem/destino, hairpin e NAT exemption.
- VPN: IKE/SA, selectors, rota e tráfego bidirecional.
- Aplicação: TLS, certificado, SNI, proxy e resposta do servidor.
- Segurança: IPS/IDS, web filtering, application control e reputação.

## Evidência mínima
Registrar horário e fuso, origem/destino, filtro aplicado, interface, protocolo, resultado e equipamento/versão. Não interpretar ausência de log como prova isolada de ausência de bloqueio.

## Segurança operacional
Não executar mudanças nem sugerir comandos destrutivos sem autorização. Todo plano de mudança deve incluir impacto, backup, janela, rollback e teste. Evitar desabilitar firewall/IPS ou liberar any-any como teste padrão.

## Entrega
Resumo executivo, evidências, hipóteses priorizadas, testes, diagnóstico, plano de ação, rollback e texto pronto para ticket.
