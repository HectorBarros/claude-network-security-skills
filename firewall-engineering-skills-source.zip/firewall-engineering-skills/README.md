# Firewall Engineering Skills

Biblioteca de Agent Skills para Claude.ai, com foco em Sophos Firewall, FortiGate, VPN, troubleshooting, auditoria e análise de pacotes.

## Instalação no Claude.ai
1. Abra Claude.ai.
2. Vá a **Personalizar → Skills** (ou Configurações → Capacidades, conforme a interface).
3. Habilite execução de código e criação de arquivos.
4. Clique em **+ → Criar skill → Fazer upload de uma skill**.
5. Envie cada ZIP individualmente e ative a Skill.

Cada ZIP contém uma pasta própria com `SKILL.md` e metadados YAML.

## Pacotes
- sophos-firewall.zip
- fortigate-firewall.zip
- vpn-engineering.zip
- firewall-troubleshooting.zip
- firewall-audit.zip
- packet-analysis.zip
- technical-report.zip

## Segurança operacional
As Skills são instruções, não substituem documentação oficial nem revisão humana. Validar comandos pela versão do firmware. Mudanças em produção exigem autorização, backup, janela, rollback e validação. Nunca inserir senhas, PSKs, tokens ou chaves privadas nos arquivos.

## GitHub
Mantenha os arquivos-fonte versionados no GitHub. Para atualizar o Claude.ai, gere novamente o ZIP da Skill alterada e faça novo upload conforme a interface disponível.
